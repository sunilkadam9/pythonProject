import shutil

from Diagram import Diagram
from FindReplace import find_replace_in_file, if_not_find_then_replace

IN_CONNECTION_LOGI1 = 'GoldProject/Logical/service.scm/'


class TestData:
    name = ""
    lg1_id = ""
    ids = []
    testdata_type = ""

    def create(self, name, testdata_type, lg1_id, output_dir):
        self.name = name
        self.testdata_type = testdata_type
        self.lg1_id = lg1_id

        destination = shutil.copyfile(IN_CONNECTION_LOGI1 + 'OperationName.ext',
                                      output_dir + '/Logical/' + name + '.scm/' + name + '_' + self.testdata_type + '_data.ext')
        print("File copy pest " + destination)
        destination1 = shutil.copytree(IN_CONNECTION_LOGI1 + 'TestData',
                                      output_dir + '/Logical/' + name + '.scm/TestData')
        print("File copy pest " + destination1)

        find_replace_in_file(destination, '$$$Test_Data_LG1$$$', self.lg1_id)
        find_replace_in_file(destination, '$$$Test_Data_TYPE$$$', self.testdata_type)
        find_replace_in_file(destination, '$$$OPERATION_NAME$$$', self.name)


