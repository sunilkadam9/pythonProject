# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
from Connection import *
from FindReplace import if_not_find_then_replace
from Operation import Operation
from TestData import TestData
from env import process_projectghp_file, process_env_file
from ids import collect_ids, generate_unique_id

CONFIG_fILE = 'Config/GV.cfg'
OUTPUT_FILE = 'output/processfile.ghp'
OUTPUT_DIR = 'output'
prefix = '-89f536e:190a7da0769:-'


def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('**************RIT Automation **************')

    engine_name = input('Engine name?\n')
    print(engine_name)

    operation_name = input('Operation name?\n')
    print(operation_name)

    service_bus_name = input('Service bus name? SB1\n')
    print(service_bus_name)

    string_before = '''<environmentVariable evdescription='''
    string_after = '''overridingSecretsNamespace="">'''
    # update project ghp
    process_projectghp_file(CONFIG_fILE, OUTPUT_FILE, string_before, string_after)

    # update env
    process_env_file('Config/LT_' + service_bus_name, OUTPUT_DIR, string_before, string_after)

    if_not_find_then_replace(OUTPUT_DIR + '''/Custom/TILLT1.ghe''', '''<evbindings>''', '''</resourceConfig>''',
                              '''<evbindings></evbindings></resourceConfig>''')
    if_not_find_then_replace(OUTPUT_DIR + '''/Custom/TILLT2.ghe''', '''<evbindings>''', '''</resourceConfig>''',
                              '''<evbindings></evbindings></resourceConfig>''')
    if_not_find_then_replace(OUTPUT_DIR + '''/Custom/TILLT3.ghe''', '''<evbindings>''', '''</resourceConfig>''',
                              '''<evbindings></evbindings></resourceConfig>''')

    ids = collect_ids(OUTPUT_DIR)
    id_ph1 = generate_unique_id(4, prefix, ids)
    id_ph2 = generate_unique_id(4, prefix, ids)
    id_lg1 = generate_unique_id(4, prefix, ids)
    ids.append(id_ph1)
    ids.append(id_ph2)
    ids.append(id_lg1)
    ids.append(id_ph1)
    ids.append(id_ph2)
    ids.append(id_lg1)
    print(f"Collected IDs: {ids}")
    conn = Connection()
    conn.create('TIB_EMS_SB', '[]', 'JMS', id_ph1, id_ph2, id_lg1,OUTPUT_DIR)

    #operation
    sv_name=operation_name
    op_name=operation_name

    sv_lg1_id = generate_unique_id(4, prefix, ids)
    ids.append(sv_lg1_id)
    op_lg1_id = generate_unique_id(4, prefix, ids)
    ids.append(op_lg1_id)
    operation=Operation()
    operation.create(op_name, op_lg1_id, sv_name, sv_lg1_id, id_lg1, OUTPUT_DIR)

    #test Suite
    operation_type=0

    while True:
        operation_type = int(input('operation type?\n 1. SOAP_JMS \n2. JMS_JSON'))

        if not(operation_type > 1 or operation_type < 2):
            continue
        else:
            break

    if operation_type == 1:
        op_type = "SOAP_JMS"
    else:
        op_type = 'JMS_JSON'

    test_data_lg1_id = generate_unique_id(4, prefix, ids)
    ids.append(test_data_lg1_id)
    test_data = TestData()
    test_data.create(op_name, op_type, test_data_lg1_id, OUTPUT_DIR)


    #test Cases
    #test_case='TC001_cso2'
    #dest = shutil.copyfile(input_prj + '/Logical/service.scm/op_name.opr/TC001testcase.tc', output + '/Logical/' +
    #op_name + '.scm/' + op_name + '.opr/' + sheet + '.tc')
    #print("File copy pest " + dest)


    #print(conn.conn_type)

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
