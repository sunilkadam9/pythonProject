import os
import shutil

from Diagram import Diagram
from FindReplace import find_replace_in_file

IN_SERVICE_LOGID1 = 'GoldProject/Logical/service.scm'
OUT_SERVICE_LOGID1 = 'output/Logical/'

class Operation:
    ids = []
    service_lg1_id = ""
    service_ph1_id = ""
    service_name = ""
    operation_lg1_id = ""
    operation_ph1_id = ""
    operation_name = ""

    def __init__(self):
        self.op_name = None
        self.op_ph1_id = None
        self.op_lg1_id = None
        self.sv_name = None
        self.sv_ph1_id = None
        self.sv_lg1_id = None

    def create(self, op_name, op_lg1_id, sv_name, sv_lg1_id, connection_lg1_id, output_dir):
        self.op_name = op_name
        self.op_lg1_id = op_lg1_id
        self.sv_name = sv_name
        self.sv_lg1_id = sv_lg1_id

        Diagram.add_diagram(50 ,50, self.sv_lg1_id, output_dir)
        Diagram.add_diagram(0, 15, self.op_lg1_id, output_dir)
        print(OUT_SERVICE_LOGID1 + sv_name + ".scmmmmmmmmmmmmmm")
        os.makedirs(OUT_SERVICE_LOGID1 + sv_name + ".scm")
        destination = shutil.copyfile(IN_SERVICE_LOGID1 + "/config.scm", OUT_SERVICE_LOGID1 + sv_name + ".scm/config.scm")
        print("File copy pest " + destination)
        os.makedirs(OUT_SERVICE_LOGID1 + sv_name + ".scm/" + self.op_name + ".opr")
        destination = shutil.copyfile(IN_SERVICE_LOGID1 + "/op_name.opr/config.opr",
                                      OUT_SERVICE_LOGID1 + sv_name + ".scm/" + self.op_name + ".opr/config.opr")
        print("File copy pest " + destination)
        #os.rename(OUT_SERVICE_LOGID1 + sv_name + ".scm/" + "op_name.opr", OUT_SERVICE_LOGID1 + sv_name + ".scm/" + self.op_name + ".opr")
        find_replace_in_file(OUT_SERVICE_LOGID1 + sv_name + ".scm/config.scm", '$$$SV_LG1_id$$$', self.sv_lg1_id)
        find_replace_in_file(OUT_SERVICE_LOGID1 + sv_name + ".scm/" + self.op_name + ".opr/config.opr", '$$$TIL_EMS_SB_Con_LG1$$$',
                              connection_lg1_id)
        find_replace_in_file(OUT_SERVICE_LOGID1 + sv_name + ".scm/" + self.op_name + ".opr/config.opr",
                             '$$$OP_LG1_id$$$',
                             op_lg1_id)
