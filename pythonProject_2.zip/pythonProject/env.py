import os
OUTPUT_FILE ='output/processfile.ghp'
def read_target_file(file_path):
    with open(file_path, 'r') as file:
        return file.read()


# readfile and store in directory
def read_config(file_path):
    config = {}
    with open(file_path, 'r') as file:
        for line in file:
            key, value = line.strip().split('::')
            config[key] = value
    return config


def process_target_file(content, config, string_before, string_after):
    linespace = "        "
    for key, value in config.items():
        print("key :" + key + "Value :" + value)
        if key not in content:
            end_idx = -500
            start_idx = content.find(string_before)
            print("S_start_idx :" + str(start_idx) + " end_idx" + str(end_idx))
            end_idx = content.find(string_after)  # ,start_idx)
            print("E_start_idx :" + str(start_idx) + " end_idx" + str(end_idx))
            print("start_idx :" + str(start_idx) + " end_idx" + str(end_idx))
            if start_idx != -1 and end_idx != -1:
                insert_position = end_idx + len(string_after)
                content = content[:insert_position] + linespace + value + "\n" + content[insert_position:]
                print("Content after update inside loop " + content)

    return content


# readfile and store in directory and list
def read_configSa_Sb(file_path):
    config = {}
    with open(file_path, 'r') as file:
        for line in file:
            key, value, sa, sb = line.strip().split('::')
            config[key] = [value, sa, sb]
    return config


# process target file on key value pairs
def process_target_file(content, config, string_before, string_after):
    linespace = "\n        "
    for key, [value, sa, sb] in config.items():
        print("key :" + key + "Value :" + value)
        if key not in content:
            end_idx = -500
            start_idx = content.find(sb)
            print("S_start_idx :" + str(start_idx) + " end_idx" + str(end_idx))
            end_idx = content.find(sa)  # ,start_idx)
            print("E_start_idx :" + str(start_idx) + " end_idx" + str(end_idx))
            print("start_idx :" + str(start_idx) + " end_idx" + str(end_idx))
            if start_idx != -1 and end_idx != -1:
                insert_position = end_idx + len(sa)
                content = content[:insert_position] + linespace + value + content[insert_position:]
                print("Content after update inside looop " + content)

    return content


def process_env_file(LT_Cfg_path, target_env_path, string_before, string_after):
    # load config file

    # config= read_config(CONFIG_fILE)

    files = os.listdir(LT_Cfg_path)
    for f in files:
        if os.path.isfile(LT_Cfg_path + '/' + f):
            # config=read_config(LT_Cfg_path+'/'+f)
            config = read_configSa_Sb(LT_Cfg_path + '/' + f)
            if os.path.isfile(target_env_path + '/' + f):
                targe_content = read_target_file(target_env_path + '/' + f)
                update_content = process_target_file(targe_content, config, string_before, string_after)
                with open(target_env_path + '/' + f, 'w') as file:
                    file.write(update_content)
                    print("SSSSSSSuccess")
            else:
                dest = shutil.copyfile(LT_Cfg_path + '/copy_ghe/' + f, target_env_path + '/' + f)
                print("File copy pested " + dest)

    # load target file
    # targe_content=read_target_file(TARGET_fILE)

    # define string before and after to value to be inserted

    # update_content=process_target_file(targe_content,config,string_before,string_after)
    # print(update_content)

    print("SSSSSSSuccess22")


def process_projectghp_file(config_file, projectghp_file, string_before, string_after):
    # config= read_config(config_file)
    config = read_configSa_Sb(config_file)
    print(config_file + " == ")  # + config)
    targe_content = read_target_file(projectghp_file)
    print(projectghp_file + " == " + targe_content)
    update_content = process_target_file(targe_content, config, string_before, string_after)
    print("after content update " + update_content)
    with open(OUTPUT_FILE, 'w') as file:
        file.write(update_content)

    print("SSSSSSSuccess_project ghp")
