import os
import random
import re
import string


def find_ids_in_file(file_path):
    """
    Reads a file and extracts all 'id' occurrences using regular expressions.
    Assumes the 'id' is in the format 'id: <value>' or 'id = <value>'.
    """
    ids = []
    id_pattern = re.compile(r'''\sid="(.*)[,(.*)|"$]''', re.IGNORECASE)

    try:
        with open(file_path, 'r') as file:
            content = file.read()
            ids.extend(id_pattern.findall(content))
    except Exception as e:
        print(f"Error reading file {file_path}: {e}")

    return ids


def collect_ids(directory):
    """
    Recursively traverse the directory and subdirectories to find and collect all ids.
    """
    all_ids = []

    for root, _, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            file_ids = find_ids_in_file(file_path)
            all_ids.extend(file_ids)

    return all_ids


def generate_random_hex_chars(num_chars):
    # Define the set of hexadecimal characters
    hex_chars = string.hexdigits.lower()

    # Generate the random string
    random_hex_string = ''.join(random.choices(hex_chars, k=num_chars))
    print(random_hex_string)
    return random_hex_string


def generate_unique_id(num_chars, prefix, collection):
    id = prefix + generate_random_hex_chars(4)
    if id in collection:
        print(id + "is present in collection")
        return generate_unique_id(num_chars, prefix, collection)
    else:
        # ids.append(id)
        # print(f'ssssssssssssssss {ids}')
        return id
