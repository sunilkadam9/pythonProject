from FindReplace import if_not_find_then_replace


class Diagram:
    ids = []
    x_axis = 500
    y_axis = 500

    @staticmethod
    def add_diagram(x, y, lg1_id, output_dir):
        Diagram.x_axis = Diagram.x_axis + x
        Diagram.y_axis = Diagram.y_axis + y
        if_not_find_then_replace(output_dir + '''/Diagrams/logical.props''', lg1_id, '''</properties>''',
                                  '''<entry key="''' + lg1_id + '''>''' + str(Diagram.x_axis) + ''',''' + str(Diagram.y_axis) + '''</entry>\n</properties>''')
