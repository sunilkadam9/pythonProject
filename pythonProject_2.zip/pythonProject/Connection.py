import shutil

from Diagram import Diagram
from FindReplace import find_replace_in_file, if_not_find_then_replace

IN_CONNECTION_PHY1 = 'GoldProject/Physical/TIBCO EMS [Non JNDI_%%TIL_JMS_URL%%].edt'
IN_CONNECTION_PHY2 = 'GoldProject/Physical/TIBCO EMS [Non JNDI_%%TIL_JMS_URL%%] - TIBCO Enterprise Message Service (default).prb'
OUT_CONNECTION_PHY1 = 'output/Physical/TIBCO EMS [Non JNDI_%%TIL_JMS_URL%%].edt'
OUT_CONNECTION_PHY2 = 'output/Physical/TIBCO EMS [Non JNDI_%%TIL_JMS_URL%%] - TIBCO Enterprise Message Service (default).prb'
IN_CONNECTION_LOGI1 = 'GoldProject/Logical/TIL_JMS_SB.icm'
OUT_CONNECTION_LOGI1 = 'output/Logical/TIL_JMS_SB.icm'


class Connection:
    name = ""
    ph1_id = ""
    ph2_id = ""
    lg1_id = ""
    ids = []
    conn_type = ""

    def create(self, name, ids, conn_type, ph1_id, ph2_id, lg1_id, output_dir):
        self.name = name
        self.conn_type = conn_type
        self.ph1_id = ph1_id
        self.ph2_id = ph2_id
        self.lg1_id = lg1_id

        Diagram.add_diagram(50, 50, self.lg1_id, output_dir)
        #self.add_binding_to_all_env(self.lg1_id, self.ph1_id)

        dest = shutil.copyfile(IN_CONNECTION_PHY1, OUT_CONNECTION_PHY1)
        print("File copy pested " + dest)
        find_replace_in_file(dest, '$$$TIL_EMS_SB_Con_PH1$$$', self.ph1_id)
        dest = shutil.copyfile(IN_CONNECTION_PHY2, OUT_CONNECTION_PHY2)
        print("File copy pested " + dest)
        find_replace_in_file(dest, '$$$TIL_EMS_SB_Con_PH1$$$', self.ph1_id)
        find_replace_in_file(dest, '$$$TIL_EMS_SB_Con_PH2$$$', self.ph2_id)
        destination = shutil.copytree(IN_CONNECTION_LOGI1, OUT_CONNECTION_LOGI1)
        print("File copy pested " + destination)
        find_replace_in_file(destination + '/config.icm', '$$$TIL_EMS_SB_Con_LG1$$$', self.lg1_id)

        if_not_find_then_replace(output_dir + '''/Custom/TILLT1.ghe''',
                                 '''<evbinding evLogicalItemId="''' + self.lg1_id + '''" evPhysicalItemId="''' + self.ph1_id + '''"/>''',
                                 '''</evbindings>''',
                                 '''<evbinding evLogicalItemId="''' + self.lg1_id + '''" evPhysicalItemId="''' + self.ph1_id + '''"/></evbindings>''')

        if_not_find_then_replace(output_dir + '''/Custom/TILLT2.ghe''',
                                 '''<evbinding evLogicalItemId="''' + self.lg1_id + '''" evPhysicalItemId="''' + self.ph1_id + '''"/>''',
                                 '''</evbindings>''',
                                 '''<evbinding evLogicalItemId="''' + self.lg1_id + '''" evPhysicalItemId="''' + self.ph1_id + '''"/></evbindings>''')

        if_not_find_then_replace(output_dir + '''/Custom/TILLT3.ghe''',
                                 '''<evbinding evLogicalItemId="''' + self.lg1_id + '''" evPhysicalItemId="''' + self.ph1_id + '''"/>''',
                                 '''</evbindings>''',
                                 '''<evbinding evLogicalItemId="''' + self.lg1_id + '''" evPhysicalItemId="''' + self.ph1_id + '''"/></evbindings>''')

    #def add_to_diagram(self, lg1_id, output_dir):
    #    print(lg1_id)
    #    print(self.lg1_id)

    #def add_binding_to_all_env(self, lg1_id, ph1_id):
    #    print(self.lg1_id + " " + self.ph1_id)
