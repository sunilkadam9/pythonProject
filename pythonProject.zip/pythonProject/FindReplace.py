def find_replace_in_file(file_path, search_text, replace_text):
    # Opening our text file in read only
    # mode using the open() function
    print(file_path)
    with open(file_path, 'r') as file:
        # Reading the content of the file
        # using the read() function and storing
        # them in a new variable
        data = file.read()

        # Searching and replacing the text
        # using the replace() function
        data = data.replace(search_text, replace_text)
        print(data)

    # Opening our text file in write only
    # mode to write the replaced content
    with open(file_path, 'w') as file:
        # Writing the replaced data in our
        # text file
        file.write(data)

    # Printing Text replaced
    print("Text replaced")
    return 0


def if_not_find_then_replace(file_path, if_not_text, search_text, replace_text):
    # Opening our text file in read only
    # mode using the open() function
    with open(file_path, 'r') as file:
        # Reading the content of the file
        # using the read() function and storing
        # them in a new variable
        data = file.read()
        res = data.find(if_not_text)

        # Searching and replacing the text
        # using the replace() function
        if res == -1:
            data = data.replace(search_text, replace_text)

        # Opening our text file in write only
    # mode to write the replaced content
    with open(file_path, 'w') as file:
        # Writing the replaced data in our
        # text file
        file.write(data)

    # Printing Text replaced
    print("Text replaced")
    return 0

